"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class OrderProductEntity {
}
exports.OrderProductEntity = OrderProductEntity;
