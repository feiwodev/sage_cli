"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class OrderNotifyEntity {
    constructor() {
        this.status = 0;
    }
}
exports.OrderNotifyEntity = OrderNotifyEntity;
