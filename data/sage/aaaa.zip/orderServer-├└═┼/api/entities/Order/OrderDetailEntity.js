"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class OrderDetailEntity {
}
exports.OrderDetailEntity = OrderDetailEntity;
