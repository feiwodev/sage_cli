"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class OrderQueryEntity {
    constructor() {
        this.status = 0;
    }
}
exports.OrderQueryEntity = OrderQueryEntity;
