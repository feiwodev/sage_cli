"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BusinessTicket_1 = require("../../models/DecisionSupport/BusinessTicket");
class BusinessTicketEntity extends BusinessTicket_1.BusinessTicket {
}
exports.BusinessTicketEntity = BusinessTicketEntity;
