"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Product_1 = require("../../models/BaseSettings/Product");
class ProductEntity extends Product_1.Product {
}
exports.ProductEntity = ProductEntity;
