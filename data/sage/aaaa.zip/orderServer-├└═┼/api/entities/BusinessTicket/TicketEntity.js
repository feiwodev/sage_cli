"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Ticket_1 = require("../../models/BaseSettings/Ticket");
class TicketEntity extends Ticket_1.Ticket {
}
exports.TicketEntity = TicketEntity;
