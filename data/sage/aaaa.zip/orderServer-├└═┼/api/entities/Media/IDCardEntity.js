"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class IDCardEntity {
}
exports.IDCardEntity = IDCardEntity;
