"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class FaceEntity {
}
exports.FaceEntity = FaceEntity;
