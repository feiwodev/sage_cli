"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const SalesWin_1 = require("../../models/BaseSettings/SalesWin");
class SalesWinEntity extends SalesWin_1.SalesWin {
}
exports.SalesWinEntity = SalesWinEntity;
