"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AccessGate_1 = require("../../models/BaseSettings/AccessGate");
class AccessGateEntity extends AccessGate_1.AccessGate {
}
exports.AccessGateEntity = AccessGateEntity;
