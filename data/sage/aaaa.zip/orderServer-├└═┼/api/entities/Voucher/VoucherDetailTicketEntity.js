"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const VoucherDetailTicket_1 = require("../../models/SalesFrontDesk/VoucherDetailTicket");
class VoucherDetailTicketEntity extends VoucherDetailTicket_1.VoucherDetailTicket {
}
exports.VoucherDetailTicketEntity = VoucherDetailTicketEntity;
