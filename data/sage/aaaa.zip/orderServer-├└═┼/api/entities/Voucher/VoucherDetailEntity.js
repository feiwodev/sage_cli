"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class VoucherDetailEntity {
}
exports.VoucherDetailEntity = VoucherDetailEntity;
