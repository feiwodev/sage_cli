"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class RefundDetailEntity {
}
exports.RefundDetailEntity = RefundDetailEntity;
