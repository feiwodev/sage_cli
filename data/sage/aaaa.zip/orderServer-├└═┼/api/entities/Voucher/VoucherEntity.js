"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var VoucherType;
(function (VoucherType) {
    VoucherType[VoucherType["\u9884\u552E"] = 0] = "\u9884\u552E";
    VoucherType[VoucherType["\u51FA\u552E"] = 1] = "\u51FA\u552E";
    VoucherType[VoucherType["\u9000\u8D27"] = 2] = "\u9000\u8D27";
    VoucherType[VoucherType["\u5145\u503C"] = 3] = "\u5145\u503C";
    VoucherType[VoucherType["\u8865\u5F55"] = 4] = "\u8865\u5F55";
    VoucherType[VoucherType["\u8FD8\u5361"] = 5] = "\u8FD8\u5361";
    VoucherType[VoucherType["\u8865\u7968"] = 6] = "\u8865\u7968";
    VoucherType[VoucherType["\u5F3A\u9000"] = 7] = "\u5F3A\u9000";
    VoucherType[VoucherType["\u51B2\u7EA2"] = 8] = "\u51B2\u7EA2";
    VoucherType[VoucherType["\u8BA2\u6B63"] = 9] = "\u8BA2\u6B63";
    VoucherType[VoucherType["\u4F5C\u5E9F"] = 10] = "\u4F5C\u5E9F";
})(VoucherType = exports.VoucherType || (exports.VoucherType = {}));
class VoucherEntity {
}
exports.VoucherEntity = VoucherEntity;
